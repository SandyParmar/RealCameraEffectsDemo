//
//  ViewController.swift
//  RealCameraEffectsDemo
//
//  Created by Sandeep Parmar on 16/02/18.
//  Copyright © 2018 Sandeep Parmar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var cameraButton: UIButton!


    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func cameraButtonDidPressed(_ sender: UIButton)
    {

        let showCamera = self.storyboard?.instantiateViewController(withIdentifier: "RealTimeFilterCameraViewController")as! RealTimeFilterCameraViewController


        self.present(showCamera, animated: true, completion: nil)

        
    }
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

